import Image from "next/image";

import styles from "./cnn.module.css";

const Header = () => {
  return (
    <header className={styles.header}>
      <main className={styles.main}>
        <div className={styles.intro}>
          <div className={styles.inner}>
            <div className={styles.header__image_block}>
              <Image
                src="/images/academy_logo_light_big.png"
                className="header__cnn-image"
                layout="fill"
                objectFit="contain"
                alt="CNN"
              />
            </div>
            <div className={styles.header__line}></div>
            <div className={styles.header__image_block}>
              <Image
                src="/images/emc_logo.png"
                className={styles.header__cnn_image}
                layout="fill"
                objectFit="contain"
                alt="emc"
              />
            </div>
          </div>
          <div className={styles.header__apply}>
            <a
              target={"_blank"}
              rel="noreferrer"
              className={styles.apply_btn}
              href="https://docs.google.com/forms/d/12EBJFX56LzeT3SyQyDG-N1EFhFNkMRRAGJpMm258wN0/prefill"
            >
              Apply
            </a>
          </div>
        </div>
      </main>
    </header>
  );
};

export default Header;
