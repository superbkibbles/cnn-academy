import AboutCnn from "../../components/ar/aboutCnn";
import Apply from "../../components/ar/apply";
import ApplyDate from "../../components/ar/applyDate";
import Footer from "../../components/ar/footer";
import Header from "../../components/ar/header";
import Overview from "../../components/ar/overview";
import Pricing from "../../components/ar/pricing";
import Skills from "../../components/ar/skills";
import Structure from "../../components/ar/structure";

const CnnArabic = () => {
  return (
    <div>
      {/* Header */}
      <Header />
      {/* <!-- SECOND --> */}
      <Overview />

      {/* About CNN */}
      <AboutCnn />

      {/* Skills */}
      <Skills />

      <Apply />

      <ApplyDate />

      <Structure />

      <Pricing />
      <Footer />
    </div>
  );
};

export default CnnArabic;
