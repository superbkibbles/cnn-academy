import CnnArabic from "../../../contrainers/cnnArabic";

export default function Home() {
  return <div style={{ direction: "rtl" }}>{/* <CnnArabic /> */}</div>;
}
