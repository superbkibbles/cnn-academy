import CnnEnglish from "../../contrainers/cnnEnglish";

export default function Home() {
  return <CnnEnglish />;
}
