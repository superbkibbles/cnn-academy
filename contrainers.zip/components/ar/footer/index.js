import Image from "next/image";

import styles from "./footer.module.css";

const Footer = () => {
  return (
    <div className={styles.footer}>
      <Image
        src={"/images/smallLogo.png"}
        width={100}
        height={100}
        alt="Logo"
      />
      <div className={styles.info__container}>
        <h3 className={styles.info}>
          Email:{" "}
          <a href="mailto:cnn.academy@erbilmc.com">cnn.academy@erbilmc.com</a>
        </h3>
        <h3 className={styles.info}>
          Phone Number: <a href="tel:+9647507707121">+964 750 770 7121</a>
        </h3>
      </div>
    </div>
  );
};

export default Footer;
